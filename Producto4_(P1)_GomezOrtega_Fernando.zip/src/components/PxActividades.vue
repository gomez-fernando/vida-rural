<template>
  <section class="contenedor">
    <h2>Las actividades</h2>
    <div class="cards-block mt-4">
      <div class="article">
        <img src="assets/img/tienda.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Acampada</h3>
          <p>
            Ir de acampada es una de esas cosas que nos remite a la niñez, a la emoción de libertad y de aventura. 
          </p>
          <p>
            Nos conecta con algo muy primitivo y nos permite escapar de nuestra cómoda realidad, convirtiendo la cosa más sencilla (hervir leche, por ejemplo) en toda una aventura. Pero además, ir de acampada tiene muchos beneficios para los más pequeños.
          </p>
          <p>
            No hace falta comprar equipos especiales o material de acampada. Seguro que conoces a alguien que tiene una tienda o dos que puedas usar. 
          </p>
          <p>
            Es increíble ver cómo los niños, en un contexto nuevo, se transforman en pequeños ayudantes, ávidos por salir corriendo para aportar en algo o quedarse a tu lado para echar una mano.
          </p>

          <a
            href="https://www.educo.org/Blog/6-razones-para-ir-de-acampada-este-verano"
            target="_blank"
            class="boton"
            >Más información</a
          >
        </div>
        <!-- card-->
      </div>
      <!-- article calle 13-->
      <div class="article">
        <img src="assets/img/actividad2.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Calle 13</h3>
          <p>
            Después de habernos visitado durante la primera edición de nuestro
            encuentro. Este año vuelven Calle 13 para deleitarnos con su música.
          </p>
          <p>
            Un concierto lleno de energía en un espacio natural incomparable. Hemos preparado un escenario totalmente nuevo en la masía para nuestros conciertos.
          </p>
          <p>
            René Pérez ha colaborado en campañas sociales con UNICEF y Amnistía
            Internacional y es defensor de la educación pública latinoamericana y los derechos de los pueblos indígenas. 
          </p>
          <p>
            Fue censurado en Puerto Rico por insultar públicamente al gobernador
            Luis Fortuño en el año 2009, luego de que este terminara con 30.000
            empleos públicos en el marco de su Plan de Reconstrucción Económica.
          </p>

          <a
            href="https://www.youtube.com/watch?v=stutWBY35yw"
            target="_blank"
            class="boton"
            >Más información</a
          >
        </div>
        <!-- card-->
      </div>
      <!-- article-->
      <div class="article">
        <img src="assets/img/walking.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Caminata</h3>
          <p>
            Para muchos visitantes a Montserrat, su visita no estaría completa sin hacer una de las caminatas alrededor de la montaña de Montserrat. Es fácil planear un viaje a Montserrat y olvidar que visitarás mucho más que un monasterio: visitarás una montaña entera.
          </p>
          <p>
            Esta página te proporcionará información sobre los principales paseos que puedes tomar desde el Monasterio de Montserrat a diferentes lugares en la montaña de Montserrat
          </p>
          <p>
            Habrá información sobre la duración de las caminatas, tiempo estimado de la caminata, consejos sobre cualquier parte de la caminata que pueda ser particularmente difícil y detalles sobre qué buscar durante tu viaje. También hay enlaces a páginas más detalladas tanto acerca de la montaña de Montserrat como en el parque natural de Montserrat.
          </p>

          <a
            href="https://www.montserrat-tourist-guide.com/es/actividades/senderismo-en-montserrat.html"
            target="_blank"
            class="boton"
            >Más información</a
          >
        </div>
        <!-- card-->
      </div>
      <!-- article-->
      <div class="article">
        <img src="assets/img/espantapajaros.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Confecciona tu espantapájaros</h3>
          <p>
            Esta actividad está pensada para toda la familia y especialmente para los más pequeños.
          </p>
          <p>
            Aunque para muchas personas que se dedican a la agricultura, tener un espantapájaros significa poder proteger sus cultivos, también podemos hacerlo como una manualidad o proyecto de bricolaje con el que distraer un poco a los niños.
          </p>
          <p>
            El espantapájaros, además de divertido y mítico, es una forma de ahuyentar a los pájaros que atacan nuestro huerto o jardín estropeándonos la cosecha o las hojas y flores de nuestras plantas.
          </p>

          <a
            href="https://www.pisos.com/aldia/como-hacer-un-espantapajaros/65514/"
            target="_blank"
            class="boton"
            >Más información</a
          >
        </div>
        <!-- card-->
      </div>
      <!-- article-->
      <div class="article">
        <img src="assets/img/carrera.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Media Maratón</h3>
          <p>
            Conscientes de la importancia de desarrollar una cultura de deporte al aire libre, repetiremos la media maratón de Vida Rural que tanto éxito tuvo en su primera edición. <br> Respira le aire puro y da lo mejor de tí.
          </p>
          <p>
            La Maratón de montaña de Montserrat es una carrera con un desnivel acumulado de más de 5.000 metros. Los primeros cuatro kilómetros de carrera transcurren por el núcleo histórico de Collbató, para entrar en un tramo de carretera y escaleras. A partir de este momento nos adentramos por un sendero al Parque Natural de Montserrat.
          </p>

          <a
            href="http://events.ocisport.net/es/cursa-de-lalba-marato-de-montserrat-168/7a-marato-de-montserrat"
            target="_blank"
            class="boton"
            >Más información</a
          >
        </div>
        <!-- card-->
      </div>
      <!-- article zaz-->
      <div class="article">
        <img src="assets/img/actividad1.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Concierto de Zaz</h3>
          <p>
            Zaz es madrina del movimiento Colibríes fundado por Pierre Rabhi,
            quien también formará parte del nuestros ponentes durante este
            tercer encuentro.
          </p>
          <p>
            Se hizo famosa con su canción "Je veux", segundo tema de su primer
            álbum, Zaz, que fue lanzado al mercado el 10 de mayo de 2010.
          </p>
          <p>
            En mayo de 2010 la revista francesa Telerama anunció: "Han surgido
            rumores estas semanas: Zaz tiene una voz sagrada y será la
            revelación del verano". El 10 de mayo de 2010, Zaz lanzó su primer
            álbum al mercado.
          </p>

          <a
            href="https://www.youtube.com/watch?v=SgsMKZVI9Ok"
            target="_blank"
            class="boton"
            >Más información</a
          >
        </div>
        <!-- card-->
      </div>
      <!-- article-->
    </div>
    <hr class="divider" />
  </section>
</template>

<style>
/* ---  */
/* NOSOTROS */
/* ---  */
.nosotros {
  text-align: center;
  margin-top: 2rem;
}
@media (min-width: 992px) {
  .nosotros {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 2rem;
  }
  /* h1 {
    text-align: center;
  } */
}
.contenido-nosotros {
  display: grid;
  align-content: center;
}

/* ---  */
/* CARDS-BLOCK */
/* ---  */
.cards-block {
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: repeat(3, auto);
  gap: 1rem;
}
.cards-block img {
  width: 100%;
}
.destacado {
  grid-column: 1/2;
  grid-template-columns: 1fr;
  display: grid;
  /* gap: 1rem; */
  /* padding: 0 1rem; */
}
.destacado h3 {
  margin-top: 0;
}
@media (min-width: 768px) {
  .cards-block {
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: repeat(2, auto);
  }
  .destacado {
    grid-column: 1/3;
    grid-template-columns: repeat(2, 1fr);
    display: grid;
    /* gap: 1rem; */
    /* padding: 0 1rem; */
  }
}
.card {
  background-color: var(--claro);
  padding: var(--padding);
  border: 1px solid #c7c7c7;
}
.card p {
  font-size: 0.9rem;
  line-height: 1.8rem;
}
.article {
  display: grid;
}
.article .detalle {
  font-size: 1.4rem;
  font-weight: 400px;
}
.detalle span {
  font-weight: 300;
  color: var(--primario);
}
</style>
