<template>
  <div id="newsletter" class="container">
    <iframe
      width="80%"
      height="600"
      src="https://555f26fd.sibforms.com/serve/MUIEAOJ-CSNgWgCip88MHZBmtF2EKCaIf4deOtI3qyLpM5JfabRV0I7qESZY0Sl_swyIVrLbWZgTUuu0QOTh1xeAqXshoWhdv38BSRwY7AYul0iij-iHjV5yph6O34FRn83bV9Cf-8roEI0xbW7AUq_ZM6tD4JLOMKkKp6WH7mqQn95JKWAZs-GdOaxvI-luCSCgoMtVI1ViBK4M"
      frameborder="0"
      scrolling="auto"
      allowfullscreen
      style="display: block;margin-left: auto;margin-right: auto;max-width: 100%;"
    ></iframe>
    <!-- <hr class="divider"> -->
  </div>
</template>