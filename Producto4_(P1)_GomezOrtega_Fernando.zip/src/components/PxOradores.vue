<template>
  <section class="contenedor">
    <h2>Los ponentes</h2>
    <div class="cards-block mt-4">
      <!-- article domoterra-->
      <div class="article">
        <img src="assets/img/orador4.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Domoterra</h3>
          <p>Domoterra es una organización pionera y líder en España en difundir, formar y construir bajo la técnica de Saco Continuo de Tierra Estabilizada, también conocida como Earth-Bag ó Superadobe, creada por el arquitecto iraní Nader Khalili.</p>
          <p>En soporte al desarrollo de Comunidades Sostenibles, combinamos esta y otras técnicas de bioconstrucción con el uso de todo tipo de materiales y acabados ecológicos, energías limpias y renovables, la permacultura y el cultivo de las relaciones interpersonales sostenibles.</p>
          <p>Impulsores en el uso de la cal como material estabilizante en la técnica de Superadobe, Domoterra ha estudiado e investigado íntegramente en la utilización de materiales 100% naturales y reciclables en la construcción de estructuras de superadobe y revestimientos con cal, siendo líderes en ello.</p>

          <a href="http://www.domoterra.es/" class="boton" target="_blank">Más información</a>
        </div>
        <!-- card-->
      </div>
      <!-- article warka-->
      <div class="article">
        <img src="assets/img/orador5.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Proyecto WARKA</h3>
          <p>Cada gota cuenta. Warka Water es una torre de 10 metros de altura, fabricada a mano a partir de materiales naturales, que tiene la capacidad de recoger hasta 100 litros de agua potable desde el aire en las zonas rurales de los países en desarrollo. Diseñado por Architecture and Vision, el concepto ha sido implementado en los últimos 2 años a través de varios prototipos experimentales construidos.</p>
          <p>El agua es la fuente de toda vida. Su calidad y disponibilidad es fundamental para todos nosotros, pero el agua potable está disminuyendo continuamente. La contaminación, la creciente deforestación, el cambio climático y la desertificación vulneran aún más la disponibilidad de fuentes de agua.</p>
          <p>En la cultura etíope pastoral, el árbol Warka es una institución, su sombra se utiliza para reuniones públicas tradicionales.</p>

          <a
            href="https://www.plataformaarquitectura.cl/cl/02-351457/proyecto-warka-torres-de-bambu-que-recogen-agua-potable-desde-el-aire"
            class="boton"
            target="_blank"
          >Más información</a>
        </div>
        <!-- card-->
      </div>
            <!-- article pierre rabhi-->
      <div class="article">
        <img src="assets/img/orador3.jpg" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Pierre Rabhi</h3>
          <p>«La civilización industrial, con la productividad, la eficacia y la velocidad, nos ha alejado de los eternos ritmos del cosmos y de las estaciones, a los que la civilización agraria nos mantenía unidos.»</p>
          <p>Pierre Rabhi, uno de los activistas ecológicos más reconocidos en todo el mundo por su integridad y clarividencia nos abre su mirada y sus palabras acerca de las causas de la crisis, sus efectos y las posibles soluciones. Teniendo siempre en cuenta la razón de ser del comercio y el intercambio entre las naciones.</p>
          <p>Nació en el desierto, y pasó del silencio, de los gestos imbricados con la tierra, con el agua y con el viento, del cosmos ordenado por la tradición al caos y la densa oscuridad de los suburbios de París, la gran urbe alienante cuyo sistema adora al dios dinero, dejando de lado la conecxión del ser humano con sus raíces.</p>

          <a
            href="https://ecologiadelalma.es/entrevista-pierre-rabhi/"
            class="boton"
            target="_blank"
          >Más información</a>
        </div>
        <!-- card-->
      </div>
      <!-- pamies -->
      <div class="article">
        <img src="assets/img/orador1.png" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Josep Pàmies</h3>
          <p>A la vera del río Segre, en terrenos cultivados por la misma familia de payeses desde hace cuatro generaciones, lleva cociéndose desde hace ocho años una "dulce revolución". El artífice se llama Josep Pàmies, sabio de la tierra, horticultor y activista, cabecilla de una insurrección que corre por las macetas, los jardines y los balcones y que tiene como poderoso símbolo a la estevia: la planta prohibida.</p>
          <p>"Lo llamo la dulce revolución porque ya hemos sido testigos de muchas revoluciones violentas y hemos visto cómo acaban: con un paso atrás. Esta es una llamada a una revolución pacífica, como la que impulsó en su día Gandhi, de resistencia al sistema, de reafirmarte en lo que estás haciendo, hasta que los poderes se baten en retirada y te dejan en paz". Nos explica Pàmies con serenidad.</p>

          <a
            href="https://www.elmundo.es/blogs/elmundo/ecoheroes/2013/12/20/la-dulce-revolucion-de-josep-pamies.html"
            class="boton"
            target="_blank"
          >Más información</a>
        </div>
        <!-- card-->
      </div>
      <!-- article-->
      <div class="article">
        <img src="assets/img/orador2.png" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Adriana Cancro</h3>
          <p>El Poder de las Frutas es una plataforma creada por Adriana Cancro a principios del 2015. Está dedicada a difundir el estilo de vida frugívoro higienista, mediante sus principios como la combinación de alimentos, llamada trofología, a través de reglas de compatibilidades y clasificación de alimentos que van de la mano con un estilo de vida comprometido con el medio ambiente y la naturaleza, respetando el buen descanso,relaciones personales positivas, aire y agua pura, sol, ejercicio, actitud positiva y todo lo que esté relacionado con el bienestar físico y emocional.</p>
          <p>La acompañó desde su adolescencia un libro de cabecera: ”La Medicina Natural al Alcance de Todos” de Lezaeta Acharán, el cual fue el puntapié inicial para emprender este largo y apasionante estilo de vida.</p>

          <a
            href="https://www.adrianacancro.com/biografia/"
            class="boton"
            target="_blank"
          >Más información</a>
        </div>
        <!-- card-->
      </div>

      <!-- article-->
      <div class="article">
        <img src="assets/img/orador6.png" alt="foto conferencia" />
        <div class="card">
          <h3 class="titulo">Pedagogías alternativas</h3>
          <p>Luis González de Canales es Gestor de Proyectos en @almanatura.</p>
          <p>La educación tradicional tal y como la conocemos, parece que ha comenzado a cansar a las nuevas generaciones de padres y madres. Desde hace unos años, han comenzado a extenderse nuevas fórmulas educativas más centradas tanto en el niño o la niña, como en el medio que le rodea y la relación existente entre ambos elementos. Métodos de enseñanza como Waldorf, Montessori, o incluso las Comunidades de Aprendizaje (incluidas algunas dentro del sistema educativo), ayudan a educar a personas más proactivas, creativas, con mayor capacidad de trabajo en grupo, y demás habilidades adaptadas a las necesidades de la sociedad actual.</p>

          <a
            href="https://almanatura.com/2018/02/pedagogias-alternativas-educacion-rural/"
            class="boton"
            target="_blank"
          >Más información</a>
        </div>
        <!-- card-->
      </div>
      <!-- article-->
    </div>
    <hr class="divider" />
  </section>
</template>

<style>
/* ---  */
/* NOSOTROS */
/* ---  */
.nosotros {
  text-align: center;
  margin-top: 2rem;
}
@media (min-width: 992px) {
  .nosotros {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 2rem;
  }
  /* h1 {
    text-align: center;
  } */
}
.contenido-nosotros {
  display: grid;
  align-content: center;
}

/* ---  */
/* CARDS-BLOCK */
/* ---  */
.cards-block {
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: repeat(3, auto);
  gap: 1rem;
}
.cards-block img {
  width: 100%;
}
.destacado {
  grid-column: 1/2;
  grid-template-columns: 1fr;
  display: grid;
  /* gap: 1rem; */
  /* padding: 0 1rem; */
}
.destacado h3 {
  margin-top: 0;
}
@media (min-width: 768px) {
  .cards-block {
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: repeat(2, auto);
  }
  .destacado {
    grid-column: 1/3;
    grid-template-columns: repeat(2, 1fr);
    display: grid;
    /* gap: 1rem; */
    /* padding: 0 1rem; */
  }
}
.card {
  background-color: var(--claro);
  padding: var(--padding);
  border: 1px solid #c7c7c7;
}
.card p {
  font-size: 0.9rem;
  line-height: 1.8rem;
}
.article {
  display: grid;
}
.article .detalle {
  font-size: 1.4rem;
  font-weight: 400px;
}
.detalle span {
  font-weight: 300;
  color: var(--primario);
}
</style>
