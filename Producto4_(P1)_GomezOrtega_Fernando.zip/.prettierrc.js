module.exports = {
  tabWidth: 2,
  semi: true,
  singleQuote: false
};
